# Green Wheels Aruba

## Vision
Premium EV car dealership website for Green Wheels Aruba — showcasing electric vehicles with Caribbean warmth and sustainable luxury. Target audience: environmentally conscious car buyers in Aruba seeking modern, premium electric vehicles.

## Design
Color tokens (HSL format):
- `--primary: 180 70% 45%` (electric teal — innovation, ocean energy)
- `--accent: 16 85% 65%` (warm coral — Caribbean warmth, calls-to-action)
- `--muted: 45 30% 90%` (warm sand — subtle backgrounds)
- `--background: 0 0% 100%` (clean white)
- `--foreground: 210 25% 15%` (deep navy — text, depth)

Fonts:
- Headings: Outfit (modern, geometric, tech-forward)
- Body: Work Sans (clean, readable, approachable)

Style: Clean minimalism, generous whitespace, smooth animations, premium card designs, ocean-inspired accents, sustainable luxury feel.

## Features
- Hero section with featured EV showcase
- Vehicle inventory grid with specs
- Why Choose Electric section (benefits, savings, sustainability)
- About Green Wheels Aruba
- Contact & test drive booking
- Location & charging stations info