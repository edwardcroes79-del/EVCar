---
title: Create Hero & Vehicle Showcase
status: done
priority: urgent
type: feature
tags: [homepage, design-system]
created_by: agent
created_at: 2026-04-10
position: 0
---

## Notes
Build the main landing page with hero section featuring premium EV showcase, vehicle inventory grid, and core dealership sections. Set up design system with electric teal/coral/navy palette and Outfit/Work Sans fonts.

## Checklist
- [x] Set up design system (globals.css + tailwind.config.ts with custom colors and fonts)
- [x] Create Hero component: full-height section with headline "Drive the Future in Aruba", CTA buttons, featured EV image
- [x] Create VehicleCard component: image, name, range, 0-60 time, price, "View Details" button
- [x] Create VehicleGrid section: showcase 6 EVs with cards
- [x] Create WhyEV section: 3-column benefits grid (environmental, cost savings, performance)
- [x] Create About section: Green Wheels Aruba story, mission, Aruba location highlight
- [x] Create Contact section: test drive booking form, location map reference, contact details
- [x] Add smooth entrance animations for sections