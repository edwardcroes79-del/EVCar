// ========================================
// GREEN WHEELS ARUBA - CONTENT CONFIGURATION
// ========================================
// 
// HOW TO ADD A NEW CAR MODEL:
// ---------------------------
// 1. Add to VEHICLE INVENTORY (for homepage grid)
// 2. Add to NAVIGATION MENU > megaMenu (for navigation dropdown)
// 3. Add to MODEL DETAILS (for individual model pages)
// 
// All three sections must have matching "slug" values!
// Example: If you add slug "model-y-long-range", use it in all 3 places.
//
// ========================================

export const siteConfig = {
  // Company Information
  companyName: "Green Wheels Aruba",
  tagline: "Drive the Future",
  phone: "+297 123 4567",
  email: "info@greenwheelsaruba.com",
  address: "Palm Beach Plaza, Aruba",
  
  // Social Media Links
  socialMedia: {
    facebook: "https://facebook.com/greenwheelsaruba",
    instagram: "https://instagram.com/greenwheelsaruba",
  },

  // Business Hours
  businessHours: "Monday - Saturday: 9:00 AM - 6:00 PM",
};

// ========================================
// HERO CAROUSEL SLIDES
// ========================================
export const heroSlides = [
  {
    name: "Tesla Model 3",
    tagline: "The Perfect Daily Driver",
    description: "Experience the perfect blend of performance, safety, and efficiency in our best-selling electric sedan.",
    range: "602",
    image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=1200&q=80",
    cta: "Explore Model 3",
    link: "/models/model-3",
    accent: "from-blue-500 to-cyan-400"
  },
  {
    name: "Mercedes EQS",
    tagline: "Luxury Redefined",
    description: "The pinnacle of electric luxury with cutting-edge technology and unmatched comfort.",
    range: "547",
    image: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=1200&q=80",
    cta: "Discover EQS",
    link: "/models/eqs",
    accent: "from-purple-500 to-indigo-400"
  },
  {
    name: "BMW iX",
    tagline: "Ultimate Driving Machine",
    description: "Bold design meets powerful performance in BMW's flagship electric SUV.",
    range: "630",
      image: "https://images.unsplash.com/photo-1537984822441-cff330075342?q=80&w=1074&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
    cta: "View BMW iX",
    link: "/models/bmw-ix",
    accent: "from-orange-500 to-red-400"
  },
  {
    name: "Audi e-tron GT",
    tagline: "Gran Turismo Excellence",
    description: "Pure electric performance with Audi's legendary quattro all-wheel drive.",
    range: "488",
    image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=1200&q=80",
    cta: "Experience e-tron GT",
    link: "/models/audi-e-tron-gt",
    accent: "from-emerald-500 to-teal-400"
  },
];

// ========================================
// VEHICLE INVENTORY
// ========================================
export const vehicles = [
  {
    name: "Tesla Model S",
    range: "652 km",
    acceleration: "3.1s",
    price: "$74,990",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
    slug: "model-s"
  },
  {
    name: "Mercedes EQS",
    range: "729 km",
    acceleration: "4.1s",
    price: "$104,400",
    image: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=800&q=80",
    slug: "eqs"
  },
  {
    name: "BMW iX",
    range: "521 km",
    acceleration: "4.6s",
    price: "$87,250",
    image: "https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=800&q=80",
    slug: "bmw-ix"
  },
  {
    name: "Audi e-tron GT",
    range: "383 km",
    acceleration: "3.1s",
    price: "$102,400",
    image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=800&q=80",
    slug: "audi-e-tron-gt"
  },
  {
    name: "Tesla Model 3",
    range: "576 km",
    acceleration: "3.1s",
    price: "$40,240",
    image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=800&q=80",
    slug: "model-3"
  },
  {
    name: "Porsche Taycan",
    range: "365 km",
    acceleration: "2.6s",
    price: "$86,700",
    image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=800&q=80",
    slug: "taycan"
  },
  {
    name: "Tesla Cybertruck",
    range: "547 km",
    acceleration: "2.9s",
    price: "$79,990",
    image: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&q=80",
    slug: "cybertruck"
  },
  {
    name: "Lucid Air",
    range: "837 km",
    acceleration: "2.5s",
    price: "$87,400",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
    slug: "lucid-air"
  },
];

// ========================================
// WHY CHOOSE ELECTRIC?
// ========================================
export const evBenefits = {
  title: "Why Choose Electric?",
  subtitle: "Discover the advantages of driving electric in Aruba",
  benefits: [
    {
      title: "Zero Emissions",
      description: "Contribute to a cleaner Aruba with zero tailpipe emissions. Perfect for our island paradise.",
      icon: "Leaf",
    },
    {
      title: "Lower Operating Costs",
      description: "Save up to 70% on fuel costs. Electricity is significantly cheaper than gasoline.",
      icon: "DollarSign",
    },
    {
      title: "Instant Performance",
      description: "Experience thrilling acceleration with instant torque delivery from electric motors.",
      icon: "Zap",
    },
    {
      title: "Quiet & Smooth",
      description: "Enjoy a serene driving experience with whisper-quiet operation and smooth power delivery.",
      icon: "Wind",
    },
    {
      title: "Low Maintenance",
      description: "Fewer moving parts mean reduced maintenance costs and fewer trips to the service center.",
      icon: "Shield",
    },
    {
      title: "Future-Proof",
      description: "Invest in the future of transportation with cutting-edge technology and regular updates.",
      icon: "TrendingUp",
    },
  ],
};

// ========================================
// ABOUT SECTION
// ========================================
export const aboutContent = {
  title: "About Green Wheels Aruba",
  subtitle: "Leading the electric revolution in the Caribbean",
  story: [
    "Founded in 2020, Green Wheels Aruba is the island's premier destination for electric vehicles. We're passionate about bringing sustainable transportation solutions to Aruba while providing exceptional customer service.",
    "Our team of EV specialists is dedicated to helping you find the perfect electric vehicle for your lifestyle. From city commuters to luxury SUVs, we offer a curated selection of the world's finest EVs.",
  ],
  stats: [
    { label: "Happy Customers", value: "500+", icon: "Users" },
    { label: "EVs Sold", value: "750+", icon: "Award" },
    { label: "Years Experience", value: "4+", icon: "TrendingUp" },
    { label: "Island Coverage", value: "100%", icon: "MapPin" },
  ],
  cta: {
    text: "Visit Our Showroom",
    link: "#contact",
  },
};

// ========================================
// CONTACT & BOOKING
// ========================================
export const contactContent = {
  title: "Schedule Your Test Drive",
  subtitle: "Experience the future of driving firsthand",
  formLabels: {
    name: "Full Name",
    email: "Email Address",
    phone: "Phone Number",
    model: "Preferred Model",
    date: "Preferred Date",
    time: "Preferred Time",
    message: "Message (Optional)",
    submit: "Book Test Drive",
  },
  successMessage: "🎉 Test drive booked successfully! We'll contact you shortly to confirm.",
  contactInfo: {
    title: "Visit Us",
    subtitle: "Our showroom is open and ready to welcome you",
  },
  timeSlots: [
    "9:00 AM",
    "10:00 AM",
    "11:00 AM",
    "12:00 PM",
    "1:00 PM",
    "2:00 PM",
    "3:00 PM",
    "4:00 PM",
    "5:00 PM",
  ],
};

// ========================================
// FOOTER
// ========================================
export const footerContent = {
  description: "Aruba's premier destination for electric vehicles. Committed to sustainable transportation and exceptional customer service.",
  copyright: "© 2026 Green Wheels Aruba. All rights reserved. | Built with zero emissions 🌱",
  navigation: {
    company: {
      title: "Company",
      links: [
        { label: "About Us", href: "#about" },
        { label: "Our Mission", href: "#about" },
        { label: "Contact", href: "#contact" },
      ],
    },
    vehicles: {
      title: "Vehicles",
      links: [
        { label: "View All Models", href: "#vehicles" },
        { label: "Tesla", href: "/models/model-3" },
        { label: "Mercedes", href: "/models/eqs" },
        { label: "BMW", href: "/models/bmw-ix" },
      ],
    },
    support: {
      title: "Support",
      links: [
        { label: "Schedule Test Drive", href: "#contact" },
        { label: "Financing", href: "#contact" },
        { label: "Trade-In", href: "#contact" },
        { label: "Service Center", href: "#contact" },
      ],
    },
  },
};

// ========================================
// NAVIGATION MENU
// ========================================
export const navigationMenu = {
  logo: "Green Wheels",
  mainLinks: [
    { label: "Home", href: "/" },
    { label: "Why Electric", href: "/#why-ev" },
    { label: "About", href: "/#about" },
    { label: "Contact", href: "/#contact" },
  ],
  cta: {
    text: "Schedule Test Drive",
    href: "#contact",
  },
  // Mega menu categories
  megaMenu: {
    sedans: {
      title: "Sedans",
      description: "Sleek, efficient, perfect for daily driving",
      models: [
        {
          name: "Tesla Model S",
          range: "666 km",
          price: "$75,000",
          image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=400&q=80",
          slug: "model-s",
          badge: "Popular",
        },
        {
          name: "Tesla Model 3",
          range: "576 km",
          price: "$40,240",
          image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=400&q=80",
          slug: "model-3",
          badge: "Best Value",
        },
      ],
    },
    suvs: {
      title: "SUVs & Crossovers",
      description: "Spacious, versatile, and powerful",
      models: [
        {
          name: "Tesla Model X",
          image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
          range: "547 km",
          price: "$98,490",
          slug: "model-x",
          badge: "Popular"
        },
        {
          name: "Tesla Model Y",
          image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
          range: "525 km",
          price: "$52,990",
          slug: "model-y",
          badge: "Best Seller"
        },
        {
          name: "BMW iX",
          image: "https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=800&q=80",
          range: "630 km",
          price: "$87,250",
          slug: "bmw-ix",
        },
        {
          name: "Tesla Cybertruck",
          image: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=800&q=80",
          range: "547 km",
          price: "$79,990",
          slug: "cybertruck",
          badge: "New"
        },
      ],
    },
    luxury: {
      title: "Luxury Performance",
      description: "Premium electric excellence",
      models: [
        {
          name: "Mercedes EQS",
          image: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=800&q=80",
          range: "729 km",
          price: "$104,400",
          slug: "eqs",
          badge: "Longest Range"
        },
        {
          name: "Porsche Taycan",
          image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=800&q=80",
          range: "365 km",
          price: "$86,700",
          slug: "taycan",
          badge: "Fastest"
        },
        {
          name: "Audi e-tron GT",
          image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=800&q=80",
          range: "488 km",
          price: "$102,400",
          slug: "audi-e-tron-gt",
        },
        {
          name: "Lucid Air",
          image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=800&q=80",
          range: "837 km",
          price: "$87,400",
          slug: "lucid-air",
          badge: "New"
        },
      ],
    },
  },
};

// ========================================
// MODEL DETAIL PAGES - Complete car specifications and features
// ========================================
export const modelDetails: Record<string, {
  name: string;
  slug: string;
  tagline: string;
  description: string;
  price: string;
  image: string;
  brochureUrl?: string; // Optional PDF brochure URL
  specs: {
    range: string;
    acceleration: string;
    topSpeed: string;
    power: string;
    charging: string;
    drivetrain: string;
  };
  features: string[];
  highlights: {
    title: string;
    description: string;
  }[];
}> = {
  "model-s": {
    name: "Tesla Model S",
    slug: "model-s",
    tagline: "Plaid Speed",
    description: "The Tesla Model S sets the standard for electric performance and luxury. With its sleek design, industry-leading range, and cutting-edge technology, the Model S delivers an unparalleled driving experience.",
    price: "$74,990",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=1200&q=80",
    brochureUrl: "/brochures/tesla-model-s.pdf", // Add your PDF here
    specs: {
      range: "666 km",
      acceleration: "3.1s 0-100 km/h",
      topSpeed: "250 km/h",
      power: "670 kW",
      charging: "30 min (10-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "Autopilot with Full Self-Driving capability",
      "17-inch cinematic display",
      "Premium audio system with 22 speakers",
      "Glass roof with UV protection",
      "Heated seats front and rear",
      "Over-the-air software updates",
    ],
    highlights: [
      {
        title: "Unmatched Range",
        description: "Travel up to 652 km on a single charge, eliminating range anxiety for your daily commutes and long journeys across Aruba.",
      },
      {
        title: "Ludicrous Acceleration",
        description: "Experience 0-100 km/h in just 3.1 seconds with instant torque delivery and smooth power across all speeds.",
      },
      {
        title: "Advanced Safety",
        description: "Equipped with the most advanced safety features including automatic emergency braking, collision avoidance, and blind spot monitoring.",
      },
    ],
  },
  "model-3": {
    name: "Tesla Model 3",
    slug: "model-3",
    tagline: "Electric Performance, Affordable Price",
    description: "The Tesla Model 3 makes electric driving accessible without compromising on performance or technology. Experience the perfect balance of efficiency, style, and innovation.",
    price: "$40,240",
    image: "https://images.unsplash.com/photo-1560958089-b8a1929cea89?w=1200&q=80",
    brochureUrl: "/brochures/tesla-model-3.pdf", // Add your PDF here
    specs: {
      range: "602 km",
      acceleration: "3.1s 0-100 km/h",
      topSpeed: "261 km/h",
      power: "377 kW",
      charging: "27 min (10-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "Autopilot included as standard",
      "15-inch touchscreen display",
      "Premium connectivity",
      "Glass roof",
      "Wireless phone charging",
      "USB-C ports throughout",
    ],
    highlights: [
      {
        title: "Best Value",
        description: "Get the full Tesla experience at an accessible price point, with premium features and performance included as standard.",
      },
      {
        title: "Instant Performance",
        description: "Dual motor all-wheel drive provides incredible traction and acceleration in all conditions.",
      },
      {
        title: "Minimalist Interior",
        description: "Clean, simple design with everything controlled through the central touchscreen for an intuitive driving experience.",
      },
    ],
  },
  "model-x": {
    name: "Tesla Model X",
    slug: "model-x",
    tagline: "The Safest SUV Ever",
    description: "The Tesla Model X combines versatility, performance, and advanced safety features in a stunning electric SUV package with iconic falcon-wing doors.",
    price: "$98,490",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=1200&q=80",
    brochureUrl: "/brochures/tesla-model-x.pdf", // Add your PDF here
    specs: {
      range: "547 km",
      acceleration: "3.8s 0-100 km/h",
      topSpeed: "250 km/h",
      power: "603 kW",
      charging: "35 min (10-80%)",
      drivetrain: "Tri Motor AWD",
    },
    features: [
      "Falcon Wing rear doors",
      "Seating for up to 7 adults",
      "5,000 lbs towing capacity",
      "Panoramic windshield",
      "HEPA air filtration system",
      "22-speaker audio system",
    ],
    highlights: [
      {
        title: "Falcon Wing Doors",
        description: "Iconic upward-opening rear doors with sensors to avoid obstacles, making entry and exit effortless even in tight spaces.",
      },
      {
        title: "Family Versatility",
        description: "Spacious interior with seating for up to 7 adults and ample cargo space for all your Aruba adventures.",
      },
      {
        title: "Ultimate Safety",
        description: "5-star safety rating in every category with advanced driver assistance and collision avoidance systems.",
      },
    ],
  },
  "model-y": {
    name: "Tesla Model Y",
    slug: "model-y",
    tagline: "Versatility Meets Performance",
    description: "The Tesla Model Y is a fully electric compact SUV with unparalleled versatility, cargo space, and performance. Perfect for Aruba's roads and lifestyle.",
    price: "$52,990",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=1200&q=80",
    brochureUrl: "/brochures/tesla-model-y.pdf", // Add your PDF here
    specs: {
      range: "525 km",
      acceleration: "4.8s 0-100 km/h",
      topSpeed: "217 km/h",
      power: "346 kW",
      charging: "27 min (10-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "Spacious interior for 5 adults",
      "66 cubic feet of cargo space",
      "Panoramic glass roof",
      "Heat pump for efficiency",
      "Power liftgate",
      "Premium audio",
    ],
    highlights: [
      {
        title: "Maximum Space",
        description: "Generous cargo capacity with split-folding rear seats, perfect for beach equipment, luggage, or shopping trips.",
      },
      {
        title: "All-Weather Performance",
        description: "Dual motor all-wheel drive and advanced traction control handle any road condition with confidence.",
      },
      {
        title: "Efficiency Leader",
        description: "Heat pump system maximizes range and cabin comfort in all climates, perfect for Aruba's tropical weather.",
      },
    ],
  },
  "eqs": {
    name: "Mercedes EQS",
    slug: "eqs",
    tagline: "The S-Class of Electric Vehicles",
    description: "The Mercedes-Benz EQS represents the pinnacle of electric luxury. With a stunning design, exceptional range, and the most advanced MBUX Hyperscreen, the EQS redefines what an electric sedan can be.",
    price: "$104,400",
    image: "https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?w=1200&q=80",
    brochureUrl: "/brochures/mercedes-eqs.pdf", // Add your PDF here
    specs: {
      range: "729 km",
      acceleration: "4.1s 0-100 km/h",
      topSpeed: "210 km/h",
      power: "385 kW",
      charging: "31 min (10-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "MBUX Hyperscreen (56-inch curved display)",
      "Burmester 3D surround sound",
      "Massage seats with heating/ventilation",
      "Air suspension with adaptive damping",
      "Augmented reality navigation",
      "Executive rear seating package",
    ],
    highlights: [
      {
        title: "Hyperscreen Technology",
        description: "Revolutionary 56-inch curved glass display spanning the entire dashboard, powered by AI and offering an intuitive user experience.",
      },
      {
        title: "Supreme Comfort",
        description: "Mercedes-Benz's legendary comfort with massage seats, multi-zone climate control, and whisper-quiet cabin at all speeds.",
      },
      {
        title: "Record Range",
        description: "Industry-leading 729 km range ensures you can explore all of Aruba without worrying about charging.",
      },
    ],
  },
  "taycan": {
    name: "Porsche Taycan",
    slug: "taycan",
    tagline: "Soul, Electrified",
    description: "The Porsche Taycan brings the brand's legendary performance heritage to the electric age. Experience pure emotion in electric form with stunning design and track-ready performance.",
    price: "$86,700",
    image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=1200&q=80",
    brochureUrl: "/brochures/porsche-taycan.pdf", // Add your PDF here
    specs: {
      range: "365 km",
      acceleration: "2.6s 0-100 km/h",
      topSpeed: "260 km/h",
      power: "560 kW",
      charging: "22.5 min (5-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "800V architecture for ultra-fast charging",
      "Porsche Active Suspension Management",
      "Sport Chrono package",
      "14-way adjustable sport seats",
      "Porsche Communication Management",
      "Burmester 3D High-End sound system",
    ],
    highlights: [
      {
        title: "Fastest Charging",
        description: "Revolutionary 800V system enables 5-80% charge in just 22.5 minutes at DC fast chargers.",
      },
      {
        title: "True Sports Car",
        description: "0-100 km/h in 2.6 seconds with precise handling and the unmistakable Porsche driving experience.",
      },
      {
        title: "Timeless Design",
        description: "Iconic Porsche silhouette reimagined for the electric era, with aerodynamic efficiency and stunning presence.",
      },
    ],
  },
  "bmw-ix": {
    name: "BMW iX",
    slug: "bmw-ix",
    tagline: "The Ultimate Electric Driving Machine",
    description: "The BMW iX combines the brand's legendary driving dynamics with cutting-edge electric technology. Experience sustainable luxury without compromise in this stunning electric SAV.",
    price: "$87,250",
    image: "https://images.unsplash.com/photo-1617886903355-9354bb57751f?w=1200&q=80",
    brochureUrl: "/brochures/bmw-ix.pdf", // Add your PDF here
    specs: {
      range: "630 km",
      acceleration: "4.6s 0-100 km/h",
      topSpeed: "200 km/h",
      power: "385 kW",
      charging: "35 min (10-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "Curved display with BMW Operating System 8",
      "Bowers & Wilkins Diamond surround sound",
      "Panoramic Sky Lounge glass roof",
      "5-zone automatic climate control",
      "Parking Assistant Professional",
      "Natural materials interior",
    ],
    highlights: [
      {
        title: "Visionary Design",
        description: "Bold and modern exterior with BMW's iconic kidney grille reimagined for the electric era.",
      },
      {
        title: "Sustainable Luxury",
        description: "Interior crafted with natural and recycled materials without compromising on premium quality or comfort.",
      },
      {
        title: "Intelligent Technology",
        description: "BMW Operating System 8 with natural voice control, gesture control, and over-the-air updates.",
      },
    ],
  },
  "audi-e-tron-gt": {
    name: "Audi e-tron GT",
    slug: "audi-e-tron-gt",
    tagline: "Electric Performance Art",
    description: "The Audi e-tron GT combines breathtaking design with electrifying performance. Experience quattro all-wheel drive and legendary Audi craftsmanship in pure electric form.",
    price: "$102,400",
    image: "https://images.unsplash.com/photo-1614200187524-dc4b892acf16?w=1200&q=80",
    brochureUrl: "/brochures/audi-e-tron-gt.pdf", // Add your PDF here
    specs: {
      range: "488 km",
      acceleration: "3.1s 0-100 km/h",
      topSpeed: "245 km/h",
      power: "475 kW",
      charging: "22.5 min (5-80%)",
      drivetrain: "Dual Motor quattro AWD",
    },
    features: [
      "Electric quattro all-wheel drive",
      "Adaptive air suspension sport",
      "Bang & Olufsen 3D Premium Sound",
      "Matrix LED headlights",
      "Virtual cockpit plus",
      "Vegan interior option",
    ],
    highlights: [
      {
        title: "Gran Turismo Excellence",
        description: "Stunning four-door coupe design that turns heads while delivering supercar performance.",
      },
      {
        title: "Electric quattro",
        description: "Legendary Audi quattro all-wheel drive, now electric, providing exceptional traction and handling.",
      },
      {
        title: "Sustainable Performance",
        description: "Blistering acceleration with zero emissions, proving you don't have to choose between performance and sustainability.",
      },
    ],
  },
  "cybertruck": {
    name: "Tesla Cybertruck",
    slug: "cybertruck",
    tagline: "Built for Any Planet",
    description: "The most anticipated electric truck with unmatched durability, performance, and versatility. Featuring an armored exoskeleton and cutting-edge Tesla technology.",
    price: "$79,990",
    image: "https://images.unsplash.com/photo-1617814076367-b759c7d7e738?w=1200&q=80",
    brochureUrl: "/brochures/tesla-cybertruck.pdf", // Add your PDF here
    specs: {
      range: "547 km",
      acceleration: "2.9s 0-100 km/h",
      topSpeed: "209 km/h",
      power: "600 kW",
      charging: "30 min (10-80%)",
      drivetrain: "Tri Motor AWD",
    },
    features: [
      "Ultra-hard 30X cold-rolled stainless steel exoskeleton",
      "Armor glass windows",
      "3,500 lbs payload capacity",
      "14,000 lbs towing capacity",
      "Adaptive air suspension (up to 16 inches travel)",
      "6.5 foot vault bed with power outlets",
    ],
    highlights: [
      {
        title: "Exoskeleton Design",
        description: "Nearly impenetrable exoskeleton made from ultra-hard 30X cold-rolled stainless steel for superior durability and passenger protection.",
      },
      {
        title: "Unmatched Capability",
        description: "Haul up to 3,500 lbs payload and tow up to 14,000 lbs while accelerating from 0-100 km/h in under 3 seconds.",
      },
      {
        title: "Versatile Utility",
        description: "6.5 foot vault bed with onboard power, adjustable air suspension, and all-terrain capability for work and adventure.",
      },
    ],
  },
  "lucid-air": {
    name: "Lucid Air",
    slug: "lucid-air",
    tagline: "The World's Longest Range EV",
    description: "The Lucid Air redefines luxury electric sedans with record-breaking range, stunning design, and innovative technology. Experience the future of sustainable luxury.",
    price: "$87,400",
    image: "https://images.unsplash.com/photo-1617788138017-80ad40651399?w=1200&q=80",
    brochureUrl: "/Brochures/dummy_1.pdf", // Fixed: capital B and added 's'
    specs: {
      range: "837 km",
      acceleration: "2.5s 0-100 km/h",
      topSpeed: "270 km/h",
      power: "828 kW",
      charging: "20 min (20-80%)",
      drivetrain: "Dual Motor AWD",
    },
    features: [
      "Record-breaking 837 km EPA range",
      "34-inch curved Glass Cockpit 5K display",
      "Surreal Sound Pro audio (21 speakers)",
      "DreamDrive Pro autonomous driving",
      "Expandable panoramic glass canopy roof",
      "Nappa leather interior with sustainable materials",
    ],
    highlights: [
      {
        title: "Industry-Leading Range",
        description: "With 837 km of EPA-estimated range, the Lucid Air delivers the longest range of any production EV, eliminating range anxiety completely.",
      },
      {
        title: "Blistering Performance",
        description: "Dual motor setup delivers 828 kW of power for 0-100 km/h in just 2.5 seconds, combining luxury with supercar acceleration.",
      },
      {
        title: "Space Redefined",
        description: "Innovative design maximizes interior space with a minimalist aesthetic, offering first-class comfort and cutting-edge technology.",
      },
    ],
  },
};



