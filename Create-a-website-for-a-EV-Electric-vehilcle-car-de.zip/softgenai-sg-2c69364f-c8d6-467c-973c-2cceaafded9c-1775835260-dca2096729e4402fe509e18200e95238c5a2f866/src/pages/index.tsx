import { Navigation } from "@/components/Navigation";
import { Hero } from "@/components/Hero";
import { VehicleGrid } from "@/components/VehicleGrid";
import { WhyEV } from "@/components/WhyEV";
import { About } from "@/components/About";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navigation />
      <main className="pt-20">
        <Hero />
        <VehicleGrid />
        <WhyEV />
        <About />
        <Contact />
        <Footer />
      </main>
    </>
  );
}