import { GetStaticPaths, GetStaticProps } from "next";
import Link from "next/link";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Battery, Zap, Gauge, ArrowLeft, Calendar, CheckCircle, ChevronRight, Download, Route, Award } from "lucide-react";
import { SEO } from "@/components/SEO";
import { modelDetails } from "@/config/content";
import { Card, CardContent } from "@/components/ui/card";

interface ModelPageProps {
  model: typeof modelDetails[keyof typeof modelDetails];
  slug: string;
}

export default function ModelPage({ model, slug }: ModelPageProps) {
  return (
    <>
      <SEO
        title={`${model.name} - Green Wheels Aruba`}
        description={model.description}
        image={model.image}
      />
      <Navigation />
      <main className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="relative h-[70vh] flex items-center overflow-hidden">
          <div className="absolute inset-0">
            <div className="absolute inset-0 bg-gradient-to-r from-foreground/90 via-foreground/60 to-transparent z-10" />
            <img
              src={model.image}
              alt={model.name}
              className="w-full h-full object-cover"
            />
          </div>

          <div className="relative z-20 max-w-7xl mx-auto px-6 w-full">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-white/80 hover:text-white mb-8 group"
            >
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
              Back to Home
            </Link>

            <div className="max-w-3xl">
              <Badge className="mb-4 bg-primary text-white border-0">
                Electric Vehicle
              </Badge>
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4">
                {model.name}
              </h1>
              <p className="text-2xl text-white/90 font-semibold mb-6">
                {model.tagline}
              </p>
              <p className="text-xl text-white/80 mb-8 leading-relaxed">
                {model.description}
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/#contact">
                  <Button size="lg" className="bg-accent hover:bg-accent/90">
                    <Calendar className="w-5 h-5 mr-2" />
                    Schedule Test Drive
                  </Button>
                </Link>
                {model.brochureUrl && (
                  <a 
                    href={model.brochureUrl.includes('drive.google.com') 
                      ? model.brochureUrl.replace('/view?usp=sharing', '/preview')
                      : model.brochureUrl
                    } 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Button 
                      size="lg" 
                      variant="outline"
                      className="border-white/30 text-white hover:bg-white/10 backdrop-blur-sm"
                    >
                      <Download className="w-5 h-5 mr-2" />
                      Download Brochure
                    </Button>
                  </a>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Specifications */}
        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-6">
            <h2 className="text-4xl font-bold text-center mb-16">Technical Specifications</h2>
            <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <Card className="border-primary/20">
                <CardContent className="p-8 text-center">
                  <Route className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">Range</h3>
                  <p className="text-3xl font-bold text-primary mb-2">{model.specs.range}</p>
                  <p className="text-sm text-muted-foreground">EPA Estimated</p>
                </CardContent>
              </Card>

              <Card className="border-primary/20">
                <CardContent className="p-8 text-center">
                  <Gauge className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">0-60 mph</h3>
                  <p className="text-3xl font-bold text-primary mb-2">{model.specs.acceleration}</p>
                  <p className="text-sm text-muted-foreground">Performance</p>
                </CardContent>
              </Card>

              <Card className="border-primary/20">
                <CardContent className="p-8 text-center">
                  <Zap className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">Top Speed</h3>
                  <p className="text-3xl font-bold text-primary mb-2">{model.specs.topSpeed}</p>
                  <p className="text-sm text-muted-foreground">Maximum</p>
                </CardContent>
              </Card>

              <Card className="border-primary/20">
                <CardContent className="p-8 text-center">
                  <Award className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">Power</h3>
                  <p className="text-3xl font-bold text-primary mb-2">{model.specs.power}</p>
                  <p className="text-sm text-muted-foreground">Total Output</p>
                </CardContent>
              </Card>

              <Card className="border-primary/20">
                <CardContent className="p-8 text-center">
                  <Battery className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-xl font-bold mb-2">Charging</h3>
                  <p className="text-3xl font-bold text-primary mb-2">{model.specs.charging}</p>
                  <p className="text-sm text-muted-foreground">DC Fast Charge</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 bg-background">
          <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">
              Premium Features
            </h2>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {model.features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-4 rounded-xl bg-muted/30 border border-border hover:border-primary transition-all"
                >
                  <CheckCircle className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="text-foreground">{feature}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Highlights */}
        <section className="py-16 bg-muted/30">
          <div className="max-w-7xl mx-auto px-6">
            <h2 className="text-3xl font-bold text-foreground mb-12 text-center">
              Why Choose the {model.name}
            </h2>

            <div className="grid md:grid-cols-3 gap-8">
              {model.highlights.map((highlight, index) => (
                <div
                  key={index}
                  className="bg-card p-8 rounded-2xl border border-border hover:border-primary transition-all hover:shadow-lg"
                >
                  <h3 className="text-xl font-bold text-foreground mb-3">
                    {highlight.title}
                  </h3>
                  <p className="text-foreground/70 leading-relaxed">
                    {highlight.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Pricing & CTA */}
        <section className="py-16 bg-background">
          <div className="max-w-4xl mx-auto px-6 text-center">
            <div className="bg-gradient-to-br from-primary/10 to-accent/10 p-12 rounded-3xl border-2 border-primary/20">
              <p className="text-sm text-muted-foreground mb-2">Starting at</p>
              <p className="text-6xl font-bold text-foreground mb-6">{model.price}</p>
              <p className="text-lg text-foreground/70 mb-8 max-w-2xl mx-auto">
                Experience the future of driving in Aruba. Schedule your test drive today and discover why electric is the smart choice.
              </p>
              <div className="flex flex-wrap justify-center gap-4">
                <Link href="/#contact">
                  <Button size="lg" className="bg-primary hover:bg-primary/90">
                    <Calendar className="w-5 h-5 mr-2" />
                    Book Your Test Drive
                  </Button>
                </Link>
                <Link href="/">
                  <Button size="lg" variant="outline">
                    View All Models
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

export const getStaticPaths: GetStaticPaths = async () => {
  const paths = Object.keys(modelDetails).map((slug) => ({
    params: { slug },
  }));

  return {
    paths,
    fallback: false,
  };
};

export const getStaticProps: GetStaticProps<ModelPageProps> = async ({ params }) => {
  const slug = params?.slug as string;
  const model = modelDetails[slug];

  if (!model) {
    return {
      notFound: true,
    };
  }

  return {
    props: {
      model,
      slug,
    },
  };
};