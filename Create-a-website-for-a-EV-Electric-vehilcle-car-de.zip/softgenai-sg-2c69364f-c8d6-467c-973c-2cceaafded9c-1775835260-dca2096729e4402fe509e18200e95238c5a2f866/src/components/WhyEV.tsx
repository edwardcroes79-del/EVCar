import { Leaf, DollarSign, Zap, Wind, Shield, TrendingUp } from "lucide-react";
import { evBenefits } from "@/config/content";

const iconMap = {
  Leaf,
  DollarSign,
  Zap,
  Wind,
  Shield,
  TrendingUp,
};

export function WhyEV() {
  return (
    <section id="why-ev" className="py-20 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            {evBenefits.title}
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            {evBenefits.subtitle}
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {evBenefits.benefits.map((benefit, index) => {
            const IconComponent = iconMap[benefit.icon as keyof typeof iconMap];
            return (
              <div
                key={index}
                className="bg-card p-8 rounded-2xl border border-border hover:border-primary transition-all hover:shadow-lg group"
              >
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:bg-primary/20 transition-colors">
                  <IconComponent className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {benefit.title}
                </h3>
                <p className="text-foreground/70 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}