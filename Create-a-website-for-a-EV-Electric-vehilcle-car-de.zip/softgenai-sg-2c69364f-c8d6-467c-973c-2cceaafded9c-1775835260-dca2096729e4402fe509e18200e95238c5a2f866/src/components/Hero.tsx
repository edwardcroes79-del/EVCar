import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Gauge } from "lucide-react";
import Link from "next/link";
import { heroSlides } from "@/config/content";

export function Hero() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  useEffect(() => {
    if (isPaused) return;

    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [isPaused]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % heroSlides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + heroSlides.length) % heroSlides.length);
  };

  const goToSlide = (index: number) => {
    setCurrentSlide(index);
  };

  return (
    <section 
      className="relative h-screen flex items-center overflow-hidden bg-foreground/5"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Background slides */}
      {heroSlides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            currentSlide === index ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 via-foreground/40 to-transparent z-10" />
          <img
            src={slide.image}
            alt={slide.name}
            className="w-full h-full object-cover"
          />
        </div>
      ))}

      {/* Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 w-full">
        <div className="max-w-3xl">
          {heroSlides.map((slide, index) => (
            <div
              key={index}
              className={`transition-opacity duration-1000 ${
                currentSlide === index ? "opacity-100" : "opacity-0 absolute"
              }`}
            >
              <div className="inline-block mb-4">
                <div className={`bg-gradient-to-r ${slide.accent} px-6 py-2 rounded-full`}>
                  <p className="text-white font-bold text-lg">{slide.name}</p>
                </div>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 drop-shadow-2xl">
                {slide.tagline}
              </h1>
              
              <p className="text-xl md:text-2xl text-white/95 mb-6 leading-relaxed drop-shadow-lg">
                {slide.description}
              </p>

              <div className="flex items-center gap-4 mb-8">
                <div className="bg-white/20 backdrop-blur-md px-6 py-3 rounded-2xl border border-white/30">
                  <div className="flex items-center gap-2">
                    <Gauge className="w-6 h-6 text-white" />
                    <div>
                      <p className="text-xs text-white/80">Electric Range</p>
                      <p className="text-2xl font-bold text-white">{slide.range} km</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-4">
                <Link href={slide.link}>
                  <Button size="lg" className="bg-primary hover:bg-primary/90 shadow-xl">
                    {slide.cta}
                    <ChevronRight className="w-5 h-5 ml-2" />
                  </Button>
                </Link>
                <Link href="/#contact">
                  <Button 
                    size="lg" 
                    variant="outline" 
                    className="bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20 shadow-xl"
                  >
                    Schedule Test Drive
                  </Button>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes progress {
          from {
            width: 0%;
          }
          to {
            width: 100%;
          }
        }
        
        .animate-progress {
          animation: progress 5s linear;
        }
      `}</style>
    </section>
  );
}