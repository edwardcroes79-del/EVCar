import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Battery, Zap } from "lucide-react";
import Link from "next/link";

interface VehicleCardProps {
  name: string;
  range: string;
  acceleration: string;
  price: string;
  image: string;
  slug: string;
}

export function VehicleCard({
  name,
  range,
  acceleration,
  price,
  image,
  slug,
}: VehicleCardProps) {
  return (
    <div className="group bg-card rounded-2xl overflow-hidden border border-border hover:border-primary transition-all hover:shadow-xl">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-4 right-4">
          <Badge className="bg-accent text-white border-0">
            New Arrival
          </Badge>
        </div>
      </div>

      <div className="p-6 space-y-4">
        <div>
          <h3 className="text-2xl font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
            {name}
          </h3>
          <p className="text-3xl font-bold text-accent">{price}</p>
        </div>

        <div className="grid grid-cols-2 gap-4 py-4 border-y border-border">
          <div className="flex items-center gap-2">
            <Battery className="w-5 h-5 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">Range</p>
              <p className="font-semibold text-foreground">{range}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            <div>
              <p className="text-xs text-muted-foreground">0-60 mph</p>
              <p className="font-semibold text-foreground">{acceleration}</p>
            </div>
          </div>
        </div>

        <Link href={`/models/${slug}`}>
          <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-white group-hover:border-primary/90 font-semibold">
            View Details
          </Button>
        </Link>
      </div>
    </div>
  );
}