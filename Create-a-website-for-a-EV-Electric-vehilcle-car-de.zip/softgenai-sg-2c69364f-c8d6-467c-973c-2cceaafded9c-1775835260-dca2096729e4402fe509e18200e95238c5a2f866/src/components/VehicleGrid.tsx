import { VehicleCard } from "@/components/VehicleCard";
import { vehicles } from "@/config/content";

export function VehicleGrid() {
  return (
    <section id="vehicles" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-4">
            Our Electric Fleet
          </h2>
          <p className="text-lg text-foreground/70 max-w-2xl mx-auto">
            Discover our curated selection of premium electric vehicles, each offering exceptional range, performance, and sustainability.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {vehicles.map((vehicle, index) => (
            <VehicleCard key={index} {...vehicle} />
          ))}
        </div>
      </div>
    </section>
  );
}