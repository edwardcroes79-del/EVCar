import { useState, useEffect } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Zap, ChevronDown, Menu, X, Battery, DollarSign, Gauge } from "lucide-react";
import { cn } from "@/lib/utils";
import { siteConfig, navigationMenu } from "@/config/content";

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMegaMenuOpen, setIsMegaMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [mobileModelsOpen, setMobileModelsOpen] = useState(false);
  let menuCloseTimeout: NodeJS.Timeout | null = null;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleMegaMenuEnter = () => {
    if (menuCloseTimeout) {
      clearTimeout(menuCloseTimeout);
      menuCloseTimeout = null;
    }
    setIsMegaMenuOpen(true);
  };

  const handleMegaMenuLeave = () => {
    menuCloseTimeout = setTimeout(() => {
      setIsMegaMenuOpen(false);
    }, 150);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
    setMobileModelsOpen(false);
  };

  return (
    <>
      <nav
        className={cn(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
          isScrolled
            ? "bg-background/95 backdrop-blur-md shadow-md"
            : "bg-background/80 backdrop-blur-sm"
        )}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 group" onClick={closeMobileMenu}>
              <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold text-foreground">Green Wheels</span>
                <span className="text-xs text-primary font-semibold">Aruba</span>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center gap-8">
              <Link
                href="/"
                className="text-foreground/80 hover:text-primary font-medium transition-colors"
              >
                Home
              </Link>

              {/* Models Mega Menu */}
              <div
                className="relative"
                onMouseEnter={handleMegaMenuEnter}
                onMouseLeave={handleMegaMenuLeave}
              >
                <button className="flex items-center gap-1 text-foreground/80 hover:text-primary font-medium transition-colors">
                  Models
                  <ChevronDown
                    className={cn(
                      "w-4 h-4 transition-transform duration-200",
                      isMegaMenuOpen && "rotate-180"
                    )}
                  />
                </button>

                {/* Mega Menu Dropdown */}
                {isMegaMenuOpen && (
                  <div className="fixed left-0 right-0 top-20 z-50 px-6">
                    <div className="max-w-7xl mx-auto bg-background border border-border rounded-2xl shadow-2xl p-10 max-h-[calc(100vh-6rem)] overflow-y-auto animate-in fade-in slide-in-from-top-2 duration-200">
                      <div className="grid grid-cols-3 gap-10">
                        {Object.values(navigationMenu.megaMenu).map((category) => (
                          <div key={category.title}>
                            <div className="mb-6 sticky top-0 bg-background z-10 pb-4">
                              <h3 className="text-xl font-bold text-foreground mb-2">
                                {category.title}
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                {category.description}
                              </p>
                            </div>

                            <div className="space-y-4 pb-4">
                              {category.models.map((model) => (
                                <Link
                                  key={model.name}
                                  href={`/models/${model.slug}`}
                                  className="group block"
                                  onClick={() => setIsMegaMenuOpen(false)}
                                >
                                  <div className="rounded-xl overflow-hidden bg-muted/30 border border-border hover:border-primary transition-all hover:shadow-lg">
                                    <div className="aspect-video relative overflow-hidden">
                                      <img
                                        src={model.image}
                                        alt={model.name}
                                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                      />
                                      {model.badge && (
                                        <div className="absolute top-2 right-2">
                                          <span className="text-xs bg-accent text-white px-2.5 py-1 rounded-full font-semibold shadow-lg">
                                            {model.badge}
                                          </span>
                                        </div>
                                      )}
                                    </div>
                                    <div className="p-4">
                                      <h4 className="font-bold text-foreground mb-2 text-base group-hover:text-primary transition-colors">
                                        {model.name}
                                      </h4>
                                      <div className="flex items-center justify-between text-sm text-muted-foreground">
                                        <div className="flex items-center gap-1.5">
                                          <Battery className="w-4 h-4" />
                                          <span>{model.range}</span>
                                        </div>
                                        <div className="flex items-center gap-1">
                                          <DollarSign className="w-4 h-4" />
                                          <span className="font-semibold text-foreground">
                                            {model.price}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  </div>
                                </Link>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="mt-8 pt-8 border-t border-border sticky bottom-0 bg-background">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-foreground mb-1">
                              Can't find what you're looking for?
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Explore our complete electric vehicle collection
                            </p>
                          </div>
                          <Link href="/#vehicles" onClick={() => setIsMegaMenuOpen(false)}>
                            <Button size="lg" className="bg-primary hover:bg-primary/90">
                              View All Models
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <Link
                href="/#why-ev"
                className="text-foreground/80 hover:text-primary font-medium transition-colors"
              >
                Why Electric
              </Link>
              <Link
                href="/#about"
                className="text-foreground/80 hover:text-primary font-medium transition-colors"
              >
                About
              </Link>
              <Link
                href="/#contact"
                className="text-foreground/80 hover:text-primary font-medium transition-colors"
              >
                Contact
              </Link>
            </div>

            {/* CTA Button */}
            <div className="hidden lg:block">
              <Link href="/#contact">
                <Button className="bg-accent hover:bg-accent/90">
                  Schedule Test Drive
                </Button>
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="lg:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-foreground" />
              ) : (
                <Menu className="w-6 h-6 text-foreground" />
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <>
          <div 
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={closeMobileMenu}
          />
          <div className="fixed top-20 right-0 bottom-0 w-full max-w-sm bg-background shadow-2xl z-40 lg:hidden overflow-y-auto">
            <div className="p-6 space-y-6">
              <Link
                href="/"
                className="block text-lg font-medium text-foreground/80 hover:text-primary transition-colors"
                onClick={closeMobileMenu}
              >
                Home
              </Link>

              {/* Mobile Models Accordion */}
              <div>
                <button
                  onClick={() => setMobileModelsOpen(!mobileModelsOpen)}
                  className="flex items-center justify-between w-full text-lg font-medium text-foreground/80 hover:text-primary transition-colors"
                >
                  Models
                  <ChevronDown
                    className={cn(
                      "w-5 h-5 transition-transform",
                      mobileModelsOpen && "rotate-180"
                    )}
                  />
                </button>

                {mobileModelsOpen && (
                  <div className="mt-4 space-y-6 pl-4">
                    {Object.values(navigationMenu.megaMenu).map((category) => (
                      <div key={category.title}>
                        <h3 className="font-bold text-foreground mb-2">{category.title}</h3>
                        <div className="space-y-3">
                          {category.models.map((model) => (
                            <Link
                              key={model.name}
                              href={`/models/${model.slug}`}
                              className="block"
                              onClick={closeMobileMenu}
                            >
                              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/30 border border-border hover:border-primary transition-all">
                                <img
                                  src={model.image}
                                  alt={model.name}
                                  className="w-20 h-12 object-cover rounded"
                                />
                                <div className="flex-1">
                                  <h4 className="font-semibold text-sm text-foreground">
                                    {model.name}
                                  </h4>
                                  <p className="text-xs text-muted-foreground">{model.range}</p>
                                </div>
                              </div>
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <Link
                href="/#why-ev"
                className="block text-lg font-medium text-foreground/80 hover:text-primary transition-colors"
                onClick={closeMobileMenu}
              >
                Why Electric
              </Link>

              <Link
                href="/#about"
                className="block text-lg font-medium text-foreground/80 hover:text-primary transition-colors"
                onClick={closeMobileMenu}
              >
                About
              </Link>

              <Link
                href="/#contact"
                className="block text-lg font-medium text-foreground/80 hover:text-primary transition-colors"
                onClick={closeMobileMenu}
              >
                Contact
              </Link>

              <div className="pt-4 border-t border-border">
                <Link href="/#contact" onClick={closeMobileMenu}>
                  <Button className="w-full bg-accent hover:bg-accent/90">
                    Schedule Test Drive
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
}