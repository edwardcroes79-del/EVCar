import { MapPin, Award, Users, Heart, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import { aboutContent } from "@/config/content";

const iconMap = {
  MapPin,
  Award,
  Users,
  TrendingUp,
};

export function About() {
  return (
    <section id="about" className="py-20 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              {aboutContent.title}
            </h2>
            <p className="text-lg text-accent font-semibold mb-6">
              {aboutContent.subtitle}
            </p>

            <div className="space-y-4 mb-8">
              {aboutContent.story.map((paragraph, index) => (
                <p key={index} className="text-foreground/70 leading-relaxed">
                  {paragraph}
                </p>
              ))}
            </div>

            <Link href={aboutContent.cta.link}>
              <Button size="lg" className="bg-primary hover:bg-primary/90">
                <Heart className="w-5 h-5 mr-2" />
                {aboutContent.cta.text}
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {aboutContent.stats.map((stat, index) => {
              const IconComponent = iconMap[stat.icon as keyof typeof iconMap];
              return (
                <div
                  key={index}
                  className="bg-card p-8 rounded-2xl border border-border text-center hover:border-primary transition-all hover:shadow-lg group"
                >
                  <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-primary/20 transition-colors">
                    <IconComponent className="w-7 h-7 text-primary" />
                  </div>
                  <div className="text-4xl font-bold text-foreground mb-2">
                    {stat.value}
                  </div>
                  <div className="text-sm text-foreground/70">
                    {stat.label}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}