import { Zap, Facebook, Instagram, Mail, Phone } from "lucide-react";
import Link from "next/link";
import { siteConfig, footerContent } from "@/config/content";

export function Footer() {
  return (
    <footer className="bg-foreground text-background py-12">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <Zap className="w-8 h-8 text-primary" />
              <span className="text-2xl font-bold">{siteConfig.companyName}</span>
            </Link>
            <p className="text-background/70 text-sm leading-relaxed">
              {footerContent.description}
            </p>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-bold mb-4">{footerContent.navigation.company.title}</h3>
            <ul className="space-y-2">
              {footerContent.navigation.company.links.map((link, index) => (
                <li key={index}>
                  <Link href={link.href} className="text-background/70 hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Vehicles */}
          <div>
            <h3 className="font-bold mb-4">{footerContent.navigation.vehicles.title}</h3>
            <ul className="space-y-2">
              {footerContent.navigation.vehicles.links.map((link, index) => (
                <li key={index}>
                  <Link href={link.href} className="text-background/70 hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-bold mb-4">{footerContent.navigation.support.title}</h3>
            <ul className="space-y-2">
              {footerContent.navigation.support.links.map((link, index) => (
                <li key={index}>
                  <Link href={link.href} className="text-background/70 hover:text-primary transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border/40 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-muted-foreground text-sm">
              © {new Date().getFullYear()} Green Wheels Aruba. All rights reserved.
            </p>
            <div className="flex gap-6">
              <Link href="/privacy" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-muted-foreground hover:text-foreground text-sm transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}