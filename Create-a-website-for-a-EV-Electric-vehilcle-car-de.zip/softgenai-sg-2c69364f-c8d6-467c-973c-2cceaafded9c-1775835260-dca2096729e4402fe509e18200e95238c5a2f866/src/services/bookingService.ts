import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export interface TestDriveBooking {
  full_name: string;
  email: string;
  phone: string;
  preferred_model: string;
  preferred_date: string;
  preferred_time: string;
  message?: string;
}

export const bookingService = {
  /**
   * Create a new test drive booking
   */
  async createBooking(booking: TestDriveBooking) {
    const { data, error } = await supabase
      .from("test_drive_bookings")
      .insert({
        full_name: booking.full_name,
        email: booking.email,
        phone: booking.phone,
        preferred_model: booking.preferred_model,
        preferred_date: booking.preferred_date,
        preferred_time: booking.preferred_time,
        message: booking.message || null,
      })
      .select()
      .single();

    console.log("Create booking:", { data, error });

    if (error) {
      console.error("Booking error:", error);
      throw error;
    }

    return data;
  },

  /**
   * Get all bookings (for admin purposes)
   */
  async getAllBookings() {
    const { data, error } = await supabase
      .from("test_drive_bookings")
      .select("*")
      .order("created_at", { ascending: false });

    console.log("Get all bookings:", { data, error });

    if (error) {
      console.error("Error fetching bookings:", error);
      throw error;
    }

    return data || [];
  },

  /**
   * Get bookings by email
   */
  async getBookingsByEmail(email: string) {
    const { data, error } = await supabase
      .from("test_drive_bookings")
      .select("*")
      .eq("email", email)
      .order("created_at", { ascending: false });

    console.log("Get bookings by email:", { data, error });

    if (error) {
      console.error("Error fetching bookings:", error);
      throw error;
    }

    return data || [];
  },
};