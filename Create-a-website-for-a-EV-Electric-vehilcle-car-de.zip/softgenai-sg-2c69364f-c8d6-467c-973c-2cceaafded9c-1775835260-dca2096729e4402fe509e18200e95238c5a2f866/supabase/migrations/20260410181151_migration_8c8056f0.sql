-- Create test_drive_bookings table
CREATE TABLE IF NOT EXISTS public.test_drive_bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  preferred_model TEXT NOT NULL,
  preferred_date DATE NOT NULL,
  preferred_time TEXT NOT NULL,
  message TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.test_drive_bookings ENABLE ROW LEVEL SECURITY;

-- T3 Policy - Anonymous insert for public form submissions
CREATE POLICY "anon_insert_bookings" ON public.test_drive_bookings 
  FOR INSERT 
  WITH CHECK (true);

-- Public read for admin purposes (optional - can be removed if you don't need it)
CREATE POLICY "public_read_bookings" ON public.test_drive_bookings 
  FOR SELECT 
  USING (true);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_bookings_created_at ON public.test_drive_bookings(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_bookings_email ON public.test_drive_bookings(email);